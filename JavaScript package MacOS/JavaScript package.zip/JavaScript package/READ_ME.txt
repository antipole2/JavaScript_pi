Instructions for installing the JavaScript plugin

(1) Run the installer as usual
(2) Locate the OpenCPN application and how the package contents (use cntl-click on the application)
	Within the application, navigate to Contents > SharedSupport > plugins > JavaScript_pi
(3) In that folder you will see a folder named 'data'.
(4) Copy the folder 'scripts' included with the installer into the JavaScript_pi folder so that the
	scripts folder is at the same level as the data folder.
(5)	Close the application contents.
(6) Read the User Guide and enjoy!